package com.uty.edukasipenyakit

class penyakit (
    var nama: String = "",
    var detail: String = "",
    var photo: Int = 0
)

