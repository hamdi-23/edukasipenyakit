package com.uty.edukasipenyakit
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MoveActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_move_with_data)
    }
}